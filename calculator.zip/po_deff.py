class Poke_deff :
    """Clase que define el score defensivo de un pokemon"""

    def __init__(self, deff, typ):
        self.deff = deff
        self.typ = typ
        self.srt = "Deffender pokemon type {} with deffense over {}".format(self.typ,self.deff)
    def pok_deff_str(self):
        return self.srt
    def deff_score(self):
        return float(self.deff)
    def deff_type(self):
        return self.typ

#p_d=Poke_deff(25,"Plant")

#pd = Poke_deff(23,"Water")
#pdd = Poke_deff(2,"Water")

#total = pd.deff_score + pdd.deff_score


#print(p_d.deff_score())
#print(p_d.deff_type())
#print(p_d.pok_deff_str())