class Poke_att :
    """"Clase que define el dmg de un pokemon"""

    def __init__(self, att, typ):
        self.att = att
        self.typ = typ
        self.srt = "Attacker pokemon type {} with dmg over {}".format(self.typ,self.att)
    def pok_att_str(self):
        return self.srt
    def attk_score(self):
        return float(self.att)
    def attk_type(self):
        return self.typ

#p_a = Poke_att(50,"Water")

#print(p_a.attk_score())
#print(p_a.attk_type())
#print(p_a.pok_att_str())
