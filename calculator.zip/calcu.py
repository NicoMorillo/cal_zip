from po_attack import Poke_att
from po_deff import Poke_deff
from dmg_spc import spc_conf
import time

def combat(attk, t_a, deff, t_d):

    p_a = Poke_att(attk,t_a)
    p_d = Poke_deff(deff,t_d)

    a = p_a.attk_type()
    b = p_d.deff_type()
    attk_score = p_a.attk_score()
    deff_score = p_d.deff_score()
    spc_t= spc_conf(a,b)


    z = 50 * ((attk_score) / (deff_score)) * spc_t

    time.sleep(2)
    if spc_t == 1:
        return ("Damage: {} Is a normal attack".format(round(z,2)))
    elif spc_t == 2:
        return ("Damage: {} Is a super-efective".format(round(z,2)))
    else :
        return ("Damage: {} Is not very effective".format(round(z,2)))