from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

from calcu import combat

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():

    attk = request.form['attk']
    t_a = str (request.form['t_a'])
    deff = str (request.form['deff'])
    t_d = request.form['t_d']

    result = combat(attk,t_a,deff,t_d)

    return render_template('index.html', prediction_text=str(result))

if __name__ == "__main__":
    app.run(debug=True)