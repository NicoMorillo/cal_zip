def spc_conf(attk, deff):
    w = "water"
    f = "fire"
    p = "plant"
    e = "electric"
    
    spe = float(2)
    neu = float(1)
    no_ef = float(0.5)

    if attk == w and deff == f :
        return spe
    elif attk == w and deff == p :
        return no_ef
    elif attk == w and deff == w :
        return no_ef
    elif attk == w and deff == e :
        return neu


    if attk == f and deff == p :
        return spe
    if attk == f and deff == w :
        return no_ef
    if attk == f and deff == f :
        return no_ef
    if attk == f and deff == e :
        return neu


    if attk == p and deff == f :
        return no_ef
    elif attk == p and deff == p :
        return no_ef
    elif attk == p and deff == w :
        return spe
    elif attk == p and deff == e :
        return neu

    if attk == e and deff == f :
        return neu
    elif attk == e and deff == p :
        return no_ef
    elif attk == e and deff == w :
        return spe
    elif attk == e and deff == e :
        return neu

#attk = input("Attack spect: ")
#deff = input("Deffense spect: ")
#x = spc_conf(attk, deff)
#x = spc_conf(attk, deff)
#print(x)

#print(spc_conf("water","fire"))
